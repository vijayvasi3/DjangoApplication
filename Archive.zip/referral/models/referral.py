from django.db import models
from .department import Department


class Referral(models.Model):
    referralFirstName = models.CharField(max_length=50)
    referralLastName = models.CharField(max_length=50)
    referralEmailId = models.EmailField()
    referralDepartment = models.ForeignKey(Department, on_delete=models.CASCADE, default=0)
    referralImage = models.ImageField(upload_to='uploads/referralPics/')
    referralResume = models.FileField(upload_to='uploads/resumes/')

    @staticmethod
    def get_all_referrals():
        return Referral.objects.all()

    @staticmethod
    def get_all_referrals_by_id(department_id):
        if department_id:
            return Referral.objects.filter(referralDepartment=department_id)
        else:
            return Referral.get_all_referrals()
