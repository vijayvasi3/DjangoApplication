from django.db import models


class Department(models.Model):
    departmentName = models.CharField(max_length=25)

    @staticmethod
    def get_all_departments():
        return Department.objects.all()

    def __str__(self):
        return self.departmentName
