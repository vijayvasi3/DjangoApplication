from django.db import models


class Employee(models.Model):
    employeeFirstName = models.CharField(max_length=20)
    employeeLastName = models.CharField(max_length=20)
    employeeEmail = models.EmailField()
    employeePhoneNumber = models.CharField(max_length=10)
    employeePassword = models.CharField(max_length=500)

    def register_employee(self):
        self.save()


    @staticmethod
    def get_employee_by_email(email):
        try:
            return Employee.objects.get(employeeEmail = email)
        except:
            return False

    def isExists(self):
        if Employee.objects.filter(employeeEmail=self.employeeEmail):
            return True
        else:
            return False

