from django.contrib import admin
from .models.referral import Referral
from .models.department import Department
from.models.employee import Employee


# Register your models here.
class AdminReferral(admin.ModelAdmin):
    list_display = ['referralFirstName', 'referralLastName', 'referralEmailId', 'referralDepartment', 'referralImage',
                    'referralResume']


class AdminDepartment(admin.ModelAdmin):
    list_display = ['departmentName']


class AdminEmployee(admin.ModelAdmin):
    list_display = ['employeeFirstName', 'employeeLastName', 'employeeEmail', 'employeePhoneNumber', 'employeePassword']


# Register your models here.
admin.site.register(Referral, AdminReferral)
admin.site.register(Department, AdminDepartment)
admin.site.register(Employee, AdminEmployee)
