from django.contrib.auth.hashers import make_password
from django.http import HttpResponse
from django.shortcuts import render
from django.views import View

from referral.models.employee import Employee


class Signup(View):
    def get(self, request):
        return render(request, 'signup.html')

    def post(self, request):
        employeeFirstName = request.POST.get('firstName')
        employeeLastName = request.POST.get('lastName')
        employeeEmail = request.POST.get('email')
        employeePhoneNumber = request.POST.get('phone')
        employeePassword = request.POST.get('password')

        # This dictionary gets the current values entered in the form
        current_values = {
            'employeeFirstName': employeeFirstName,
            'employeeLastName': employeeLastName,
            'employeeEmail': employeeEmail,
            'employeePhoneNumber': employeePhoneNumber,
        }

        # Creation of Employee
        employee = Employee(
            employeeFirstName=employeeFirstName,
            employeeLastName=employeeLastName,
            employeeEmail=employeeEmail,
            employeePhoneNumber=employeePhoneNumber,
            employeePassword=employeePassword
        )

        error_message = self.validateEmployee(employee)

        if not error_message:
            employee.employeePassword = make_password(employee.employeePassword)
            employee.register_employee()
            return HttpResponse('SignUp Successful !!')
        else:
            current_entered_data = {
                'error': error_message,
                'enteredData': current_values
            }
            return render(request, 'signup.html', current_entered_data)

    def validateEmployee(self, employee):
        error_message = None
        if not employee.employeeFirstName:
            error_message = "First Name Required !!"
        elif len(employee.employeeFirstName) < 4:
            error_message = "First Name must be minimum 4 characters long"
        elif not employee.employeeLastName:
            error_message = "Last Name Required !!"
        elif len(employee.employeeLastName) < 4:
            error_message = "Last Name must be minimum 4 characters long"
        elif not employee.employeeEmail:
            error_message = "Email Address Required !!"
        elif not employee.employeePhoneNumber:
            error_message = "Phone Number Required !!"
        elif len(employee.employeePhoneNumber) != 10:
            error_message = "Phone Number should be 10 digits"
        elif employee.isExists():
            error_message = "Email Address Already Registered with us!!"
        return error_message
