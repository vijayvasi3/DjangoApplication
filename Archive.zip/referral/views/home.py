from django.shortcuts import render
from referral.models import Department, Referral


def index(request):
    allReferrals = None
    allDepartments = Department.get_all_departments()
    departmentId = request.GET.get('department')
    if departmentId:
        allReferrals = Referral.get_all_referrals_by_id(departmentId)
    else:
        allReferrals = Referral.get_all_referrals()

    data = {'referrals': allReferrals, 'departments': allDepartments}

    print(request.session.get('employee_email'))
    return render(request, 'index.html', data)
