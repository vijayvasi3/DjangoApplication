from django.shortcuts import render


def refer(request):
    return render(request, 'refer.html')
